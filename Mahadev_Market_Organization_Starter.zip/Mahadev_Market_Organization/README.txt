MAHADEV MARKET ORGANIZATION — FRONT-END STARTER

Files:
- index.html: app/web UI
- style.css: responsive design
- script.js: product gallery, cart, demo checkout, tracking, and IN-APP notifications
- images/: reserved for product/logo images (currently the product art uses emoji illustrations in the UI)

How to test:
1. Extract this ZIP.
2. Open index.html in a browser or upload all files/folders to the same GitHub repository root.
3. GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root).

Important limitations:
- In-app notifications are saved only in this browser/device using localStorage.
- Orders are local demo data; they are NOT shared between customers and admin devices.
- Demo admin PIN is 2468 and is NOT secure. Do not use it for real orders or production.
- To make orders shared online and admin access secure, connect Firebase/another backend.
- Push notifications while the app is closed are NOT included now; they can be integrated later (FCM/native wrapper).
- Product prices are sample/demo values. Update them before publishing.
- Product illustrations are emoji placeholders, not AI-generated product photos.
