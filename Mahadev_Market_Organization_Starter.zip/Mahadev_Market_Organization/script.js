/* Mahadev Market Organization — front-end starter.
   In-app notifications are saved in this browser's localStorage.
   This is NOT a shared online database or secure production admin system.
   Later: connect Firebase/secure backend and add push notifications separately. */
const ADMIN_PHONE = "8757360888";
const DEMO_ADMIN_PIN = "2468";
const products = [
  {id:"atta", name:"Wheat Flour", hindi:"आटा", category:"आटा और अनाज", price:45, unit:"1 kg", emoji:"🌾", stock:50},
  {id:"sattu", name:"Sattu", hindi:"सत्तू", category:"आटा और अनाज", price:70, unit:"1 kg", emoji:"🥣", stock:40},
  {id:"besan", name:"Besan", hindi:"बेसन", category:"आटा और अनाज", price:85, unit:"1 kg", emoji:"🟡", stock:35},
  {id:"rice", name:"Rice", hindi:"चावल", category:"आटा और अनाज", price:55, unit:"1 kg", emoji:"🍚", stock:60},
  {id:"arhar", name:"Arhar Dal", hindi:"अरहर दाल", category:"दालें", price:120, unit:"1 kg", emoji:"🫘", stock:30},
  {id:"moong", name:"Moong Dal", hindi:"मूंग दाल", category:"दालें", price:110, unit:"1 kg", emoji:"🫛", stock:30},
  {id:"masoor", name:"Masoor Dal", hindi:"मसूर दाल", category:"दालें", price:95, unit:"1 kg", emoji:"🫘", stock:30},
  {id:"chana", name:"Chana Dal", hindi:"चना दाल", category:"दालें", price:85, unit:"1 kg", emoji:"🟠", stock:30},
  {id:"haldi", name:"Turmeric Powder", hindi:"हल्दी", category:"मसाले", price:35, unit:"200 g", emoji:"🟨", stock:40},
  {id:"mirch", name:"Red Chilli Powder", hindi:"लाल मिर्च", category:"मसाले", price:45, unit:"200 g", emoji:"🌶️", stock:40},
  {id:"dhaniya", name:"Coriander Powder", hindi:"धनिया", category:"मसाले", price:35, unit:"200 g", emoji:"🌿", stock:40}
];
let cart = JSON.parse(localStorage.getItem("mm_cart") || "{}");
let orders = JSON.parse(localStorage.getItem("mm_orders") || "[]");
let notifications = JSON.parse(localStorage.getItem("mm_notifications") || "[]");
let selectedCategory = "सभी";
let adminLoggedIn = false;

const $ = id => document.getElementById(id);
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const save = () => {
  localStorage.setItem("mm_cart", JSON.stringify(cart));
  localStorage.setItem("mm_orders", JSON.stringify(orders));
  localStorage.setItem("mm_notifications", JSON.stringify(notifications));
};
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("toast").classList.add("hidden"), 2800);
}
function addNotification(title, message, icon="🔔") {
  notifications.unshift({id:Date.now()+Math.random(), title, message, icon, time:new Date().toISOString(), read:false});
  notifications = notifications.slice(0,100);
  save(); renderNotifications();
}
function renderNotifications() {
  const unread = notifications.filter(n=>!n.read).length;
  $("notificationBadge").textContent = unread;
  $("notificationBadge").classList.toggle("hidden", unread===0);
  const list = $("notificationList");
  if (!notifications.length) {
    list.innerHTML = '<div class="empty-state"><b>🔔</b><strong>अभी कोई सूचना नहीं है</strong><p>ऑर्डर देने या स्टेटस बदलने पर सूचनाएँ यहाँ दिखेंगी।</p></div>';
    return;
  }
  list.innerHTML = notifications.map(n => `<article class="notice ${n.read?'':'unread'}">
    <div class="notice-icon">${n.icon}</div><div><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.message)}</p><time>${new Date(n.time).toLocaleString("hi-IN",{dateStyle:"medium",timeStyle:"short"})}</time></div>
  </article>`).join("");
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function renderProducts() {
  const q = $("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p => (selectedCategory==="सभी"||p.category===selectedCategory) &&
    (p.name.toLowerCase().includes(q)||p.hindi.includes(q)||p.category.includes(q)));
  $("productGrid").innerHTML = filtered.length ? filtered.map(p=>`<article class="product-card">
    <div class="product-art" role="img" aria-label="${p.hindi}">${p.emoji}</div>
    <h3>${p.name}</h3><p class="sub">${p.hindi} · ${p.unit}</p>
    <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">+ जोड़ें</button></div>
  </article>`).join("") : '<div class="no-products">कोई प्रोडक्ट नहीं मिला। दूसरा नाम खोजें।</div>';
  $("categoryFilters").innerHTML = ["सभी",...new Set(products.map(p=>p.category))].map(c=>`<button class="filter-btn ${c===selectedCategory?'active':''}" data-category="${c}">${c}</button>`).join("");
}
function cartQty() { return Object.values(cart).reduce((a,b)=>a+b,0); }
function cartTotal() { return Object.entries(cart).reduce((sum,[id,qty])=>sum+(products.find(p=>p.id===id)?.price||0)*qty,0); }
function renderCart() {
  $("cartCount").textContent=cartQty();
  const entries=Object.entries(cart).filter(([id,qty])=>qty>0);
  $("cartItems").innerHTML=entries.length ? entries.map(([id,qty])=>{
    const p=products.find(x=>x.id===id); if(!p)return "";
    return `<div class="cart-line"><div class="mini-art">${p.emoji}</div><div class="line-info"><strong>${p.hindi}</strong><small>${money(p.price)} / ${p.unit}</small></div><div class="qty"><button data-qty="${id}" data-delta="-1">−</button><b>${qty}</b><button data-qty="${id}" data-delta="1">+</button></div></div>`;
  }).join("") : '<div class="empty-state"><b>🛒</b><strong>कार्ट खाली है</strong><p>पहले प्रोडक्ट गैलरी से सामान जोड़ें।</p></div>';
  $("cartTotal").textContent=money(cartTotal());
  $("checkoutOpen").disabled=!entries.length;
  $("checkoutOpen").style.opacity=entries.length?1:.55;
}
function openPanel(id) { $(id).classList.remove("hidden"); document.body.style.overflow="hidden"; }
function closePanel(id) { $(id).classList.add("hidden"); if(!document.querySelector(".overlay:not(.hidden)")) document.body.style.overflow=""; }
function renderAdmin() {
  $("adminOrders").innerHTML=orders.length ? orders.slice().reverse().map(o=>`<div class="admin-order"><strong>${o.id}</strong> · ${escapeHtml(o.name)}<br>${money(o.total)} · ${escapeHtml(o.phone)}<br><select data-status="${o.id}">${["ऑर्डर मिला","स्वीकार किया","तैयारी में","डिलीवरी के लिए निकला","डिलीवर हो गया","रद्द"].map(s=>`<option ${o.status===s?'selected':''}>${s}</option>`).join("")}</select></div>`).join("") : '<p class="muted">अभी कोई ऑर्डर इस डिवाइस में सेव नहीं है।</p>';
  $("adminProducts").innerHTML=products.map(p=>`<div class="admin-product"><strong>${p.hindi}</strong><label>₹<input type="number" min="0" data-price="${p.id}" value="${p.price}" aria-label="${p.hindi} कीमत"></label><label>स्टॉक<input type="number" min="0" data-stock="${p.id}" value="${p.stock}" aria-label="${p.hindi} स्टॉक"></label></div>`).join("");
}
$("productGrid").addEventListener("click",e=>{
  const b=e.target.closest("[data-add]"); if(!b)return;
  const id=b.dataset.add; cart[id]=(cart[id]||0)+1; save(); renderCart(); toast("कार्ट में जोड़ा गया"); 
});
$("categoryFilters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;selectedCategory=b.dataset.category;renderProducts();});
$("searchInput").addEventListener("input",renderProducts);
$("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(!b)return;const id=b.dataset.qty;cart[id]=(cart[id]||0)+Number(b.dataset.delta);if(cart[id]<=0)delete cart[id];save();renderCart();});
$("notificationBell").onclick=()=>openPanel("notificationPanel");
$("bottomNotifications").onclick=()=>openPanel("notificationPanel");
$("cartOpen").onclick=$("bottomCart").onclick=()=>{renderCart();openPanel("cartPanel");};
$("shopNow").onclick=()=>document.getElementById("productsSection").scrollIntoView({behavior:"smooth"});
$("trackOpen").onclick=$("trackOpen2").onclick=()=>openPanel("trackPanel");
$("checkoutOpen").onclick=()=>{if(!cartQty())return;closePanel("cartPanel");openPanel("checkoutPanel");};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closePanel(b.dataset.close));
document.querySelectorAll(".overlay").forEach(o=>o.addEventListener("click",e=>{if(e.target===o)closePanel(o.id);}));
document.querySelectorAll(".nav-item[data-target]").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));b.classList.add("active");$(b.dataset.target==="home"?"home":b.dataset.target)?.scrollIntoView({behavior:"smooth"});});
$("markRead").onclick=()=>{notifications.forEach(n=>n.read=true);save();renderNotifications();toast("सभी सूचनाएँ पढ़ी हुई मान ली गईं");};
$("clearNotifications").onclick=()=>{notifications=[];save();renderNotifications();toast("सूचनाएँ हटा दी गईं");};
$("checkoutForm").onsubmit=e=>{
  e.preventDefault();if(!cartQty())return;
  const phone=$("customerPhone").value.trim();
  if(!/^\d{10}$/.test(phone)){toast("कृपया 10 अंकों का मोबाइल नंबर लिखें");return;}
  const order={id:"MM-"+Math.random().toString(10).slice(2,8),name:$("customerName").value.trim(),phone,address:$("customerAddress").value.trim(),items:Object.entries(cart).map(([id,qty])=>({id,qty,name:products.find(p=>p.id===id)?.hindi})),total:cartTotal(),status:"ऑर्डर मिला",createdAt:new Date().toISOString()};
  orders.push(order);cart={};save();renderCart();
  addNotification("ऑर्डर सफलतापूर्वक दर्ज हुआ",`आपका Order ID ${order.id} है। कुल राशि ${money(order.total)}।`, "🛒");
  closePanel("checkoutPanel");$("checkoutForm").reset();
  toast("ऑर्डर दर्ज हुआ — Order ID: "+order.id);
  setTimeout(()=>{ $("trackOrderId").value=order.id;$("trackPhone").value=order.phone;openPanel("trackPanel"); },700);
};
$("trackForm").onsubmit=e=>{
  e.preventDefault();const id=$("trackOrderId").value.trim().toUpperCase(),phone=$("trackPhone").value.trim();
  const order=orders.find(o=>o.id.toUpperCase()===id&&o.phone===phone);
  $("trackResult").innerHTML=order?`<div class="track-card"><strong>${order.id}</strong><p>कुल राशि: <b>${money(order.total)}</b></p><p>स्टेटस: <span class="status-chip">${escapeHtml(order.status)}</span></p><p class="muted">ऑर्डर: ${order.items.map(i=>`${escapeHtml(i.name)} × ${i.qty}`).join(", ")}</p></div>`:'<div class="track-card">इस डिवाइस में इस Order ID और मोबाइल नंबर का ऑर्डर नहीं मिला।</div>';
};
$("adminOpen").onclick=()=>openPanel("adminPanel");
$("adminLoginForm").onsubmit=e=>{
  e.preventDefault();
  if($("adminPhone").value.trim()!==ADMIN_PHONE||$("adminPin").value!==DEMO_ADMIN_PIN){toast("डेमो लॉगिन विवरण सही नहीं है");return;}
  adminLoggedIn=true;$("adminContent").classList.remove("hidden");$("adminLoginForm").classList.add("hidden");renderAdmin();toast("डेमो एडमिन पैनल खुल गया");
};
$("adminLogout").onclick=()=>{adminLoggedIn=false;$("adminContent").classList.add("hidden");$("adminLoginForm").classList.remove("hidden");$("adminPin").value="";};
$("adminOrders").addEventListener("change",e=>{
  const id=e.target.dataset.status;if(!id)return;const order=orders.find(o=>o.id===id);if(!order)return;
  order.status=e.target.value;save();addNotification("ऑर्डर स्टेटस अपडेट",`Order ID ${id}: ${order.status}`,"📦");renderAdmin();toast("स्टेटस अपडेट किया गया");
});
$("adminProducts").addEventListener("change",e=>{
  const priceId=e.target.dataset.price,stockId=e.target.dataset.stock;
  if(priceId){const p=products.find(x=>x.id===priceId);if(p)p.price=Math.max(0,Number(e.target.value)||0);}
  if(stockId){const p=products.find(x=>x.id===stockId);if(p)p.stock=Math.max(0,Number(e.target.value)||0);}
  toast("डेमो में बदलाव लागू हुआ");renderProducts();renderCart();
});
/* A small sample in-app welcome notice on first launch only. */
if(!localStorage.getItem("mm_welcomed")){
  addNotification("Mahadev Market में आपका स्वागत है","आपकी ऑर्डर से जुड़ी इन-ऐप सूचनाएँ यहाँ दिखाई देंगी।","🌿");
  localStorage.setItem("mm_welcomed","yes");
}
renderProducts();renderCart();renderNotifications();
